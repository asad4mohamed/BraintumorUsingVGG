# Brain Tumor Detection using VGG16

This GitHub-ready archive includes the original training/testing notebooks, HTML templates, and static UI assets.

## Excluded to keep the repository small
- `vgg16_brain_tumor_model.h5` (trained weights, approximately 254 MB)
- `Training/` and `Testing/` (MRI image datasets)
- `static/uploads/` (uploaded images)
- macOS metadata and notebook checkpoints

**Important:** The notebooks may reference the excluded folders or model. Restore the dataset and trained model to their original locations to run the complete workflow. Consider Git LFS or external model/dataset storage, with permission to redistribute the data.

GitHub's browser upload has a 25 MiB per-file limit and Git blocks ordinary Git files larger than 100 MiB. Upload the extracted source files, not the ZIP itself, to make the repository browsable.
